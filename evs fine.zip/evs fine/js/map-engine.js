/**
 * AgriSmoke AI - High-Fidelity Interactive Geospatial Canvas & Plume Engine
 * 
 * Fully self-contained local map engine with real coordinate projection,
 * active fire thermal anomalies, animated smoke plume dispersion particles,
 * and Delhi-NCR urban air monitoring stations.
 * 
 * Works 100% offline in Edge file:/// mode with zero external CDN dependencies.
 */

class AgriSmokeMapEngine {
    constructor(canvasId, containerId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.container = document.getElementById(containerId);

        // Geographic Bounding Box (Indo-Gangetic Plain: Punjab, Haryana, Delhi, Western UP)
        this.geoBounds = {
            minLat: 27.8, // South of Delhi/NCR
            maxLat: 32.6, // North Punjab & Himalayan foothills
            minLng: 73.8, // West Punjab border (near Fazilka/Firozpur)
            maxLng: 78.8  // East UP (Meerut, Aligarh)
        };

        // Pan and Zoom viewport state
        this.scale = 1.0;
        this.panX = 0;
        this.panY = 0;
        this.isDragging = false;
        this.dragStartX = 0;
        this.dragStartY = 0;

        // Visual Layer toggles
        this.layers = {
            fires: true,
            plumeParticles: true,
            windVectors: true,
            stations: true,
            boundaries: true
        };

        // Smoke Plume Particle System
        this.particles = [];
        this.maxParticles = 320;
        this.windSpeed = 11.5;
        this.windAngleRad = (305 * Math.PI) / 180; // 305 deg (NW blowing toward SE)

        // Active selection / hover
        this.hoveredItem = null;
        this.selectedItem = null;

        // Tooltip element
        this.tooltip = document.getElementById('map-tooltip');

        this.init();
    }

    init() {
        this.resize();
        window.addEventListener('resize', () => this.resize());
        this.setupEventHandlers();
        this.initParticles();
        this.startAnimationLoop();
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        this.width = rect.width;
        this.height = Math.max(500, rect.height || 540);
        this.canvas.width = this.width * window.devicePixelRatio;
        this.canvas.height = this.height * window.devicePixelRatio;
        this.canvas.style.width = `${this.width}px`;
        this.canvas.style.height = `${this.height}px`;
        this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    // Convert Lat/Lng to Screen Canvas coordinates
    geoToScreen(lat, lng) {
        const normX = (lng - this.geoBounds.minLng) / (this.geoBounds.maxLng - this.geoBounds.minLng);
        // Invert Y because latitude increases northward while canvas Y increases downward
        const normY = 1.0 - ((lat - this.geoBounds.minLat) / (this.geoBounds.maxLat - this.geoBounds.minLat));

        const baseMargin = 40;
        const availWidth = this.width - baseMargin * 2;
        const availHeight = this.height - baseMargin * 2;

        const rawX = baseMargin + normX * availWidth;
        const rawY = baseMargin + normY * availHeight;

        // Apply Pan & Zoom
        const centerX = this.width / 2;
        const centerY = this.height / 2;

        const screenX = centerX + (rawX - centerX + this.panX) * this.scale;
        const screenY = centerY + (rawY - centerY + this.panY) * this.scale;

        return { x: screenX, y: screenY };
    }

    screenToGeo(screenX, screenY) {
        const centerX = this.width / 2;
        const centerY = this.height / 2;

        const rawX = (screenX - centerX) / this.scale + centerX - this.panX;
        const rawY = (screenY - centerY) / this.scale + centerY - this.panY;

        const baseMargin = 40;
        const availWidth = this.width - baseMargin * 2;
        const availHeight = this.height - baseMargin * 2;

        const normX = (rawX - baseMargin) / availWidth;
        const normY = (rawY - baseMargin) / availHeight;

        const lng = this.geoBounds.minLng + normX * (this.geoBounds.maxLng - this.geoBounds.minLng);
        const lat = this.geoBounds.maxLat - normY * (this.geoBounds.maxLat - this.geoBounds.minLat);

        return { lat, lng };
    }

    initParticles() {
        this.particles = [];
        for (let i = 0; i < this.maxParticles; i++) {
            this.particles.push(this.spawnParticle(true));
        }
    }

    spawnParticle(randomLifetime = false) {
        // Pick a random fire hotspot as origin
        const hotspots = DEMO_DATA.fireHotspots;
        const source = hotspots[Math.floor(Math.random() * hotspots.length)];
        const origin = this.geoToScreen(source.lat, source.lng);

        const progress = randomLifetime ? Math.random() : 0;
        const life = 140 + Math.random() * 100;

        return {
            sourceId: source.id,
            originLat: source.lat,
            originLng: source.lng,
            age: progress * life,
            maxLife: life,
            spreadOffset: (Math.random() - 0.5) * 24, // Lateral dispersion
            radius: 2 + Math.random() * 3,
            alpha: 0.15 + Math.random() * 0.35
        };
    }

    updateWind(speed, directionDeg) {
        this.windSpeed = speed;
        // DirectionDeg is where wind is coming FROM. Smoke travels in direction TOWARD (dir + 180)
        // Convert to standard math radians where 0 is East, 90 is South (canvas Y is down)
        const travelDirDeg = (directionDeg + 180) % 360;
        // Compass 0 is North (canvas -Y), 90 is East (+X), 180 is South (+Y), 270 is West (-X)
        const rad = ((travelDirDeg - 90) * Math.PI) / 180;
        this.windAngleRad = rad;
    }

    setupEventHandlers() {
        this.canvas.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.dragStartX = e.clientX - this.panX;
            this.dragStartY = e.clientY - this.panY;
            this.canvas.style.cursor = 'grabbing';
        });

        window.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            if (this.isDragging) {
                this.panX = e.clientX - this.dragStartX;
                this.panY = e.clientY - this.dragStartY;
            } else if (mouseX >= 0 && mouseX <= this.width && mouseY >= 0 && mouseY <= this.height) {
                this.checkHover(mouseX, mouseY);
            }
        });

        window.addEventListener('mouseup', () => {
            if (this.isDragging) {
                this.isDragging = false;
                this.canvas.style.cursor = 'default';
            }
        });

        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const zoomDelta = e.deltaY < 0 ? 1.15 : 0.87;
            this.setZoom(this.scale * zoomDelta);
        });

        this.canvas.addEventListener('click', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            this.handleClick(mouseX, mouseY);
        });

        // Zoom button controls
        document.getElementById('map-zoom-in')?.addEventListener('click', () => this.setZoom(this.scale * 1.25));
        document.getElementById('map-zoom-out')?.addEventListener('click', () => this.setZoom(this.scale * 0.8));
        document.getElementById('map-reset')?.addEventListener('click', () => this.resetView());

        // Layer toggles
        document.querySelectorAll('[data-map-layer]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const layer = btn.getAttribute('data-map-layer');
                this.layers[layer] = !this.layers[layer];
                btn.classList.toggle('active', this.layers[layer]);
            });
        });
    }

    setZoom(newScale) {
        this.scale = Math.max(0.65, Math.min(3.8, newScale));
    }

    resetView() {
        this.scale = 1.0;
        this.panX = 0;
        this.panY = 0;
    }

    checkHover(screenX, screenY) {
        let found = null;

        // Check Stations
        if (this.layers.stations) {
            for (let st of DEMO_DATA.monitoringStations) {
                const pos = this.geoToScreen(st.lat, st.lng);
                const dist = Math.hypot(screenX - pos.x, screenY - pos.y);
                if (dist <= 14) {
                    found = { type: 'station', data: st, x: pos.x, y: pos.y };
                    break;
                }
            }
        }

        // Check Fire Hotspots
        if (!found && this.layers.fires) {
            for (let fire of DEMO_DATA.fireHotspots) {
                const pos = this.geoToScreen(fire.lat, fire.lng);
                const dist = Math.hypot(screenX - pos.x, screenY - pos.y);
                if (dist <= 16) {
                    found = { type: 'fire', data: fire, x: pos.x, y: pos.y };
                    break;
                }
            }
        }

        this.hoveredItem = found;
        this.updateTooltip();
    }

    handleClick(screenX, screenY) {
        if (this.hoveredItem) {
            this.selectedItem = this.hoveredItem;
            // Dispatch custom event for UI panels
            const event = new CustomEvent('map-item-selected', { detail: this.selectedItem });
            window.dispatchEvent(event);
        }
    }

    updateTooltip() {
        if (!this.tooltip) return;

        if (!this.hoveredItem) {
            this.tooltip.style.display = 'none';
            return;
        }

        const item = this.hoveredItem;
        this.tooltip.style.display = 'block';
        this.tooltip.style.left = `${item.x + 16}px`;
        this.tooltip.style.top = `${item.y - 12}px`;

        if (item.type === 'station') {
            const st = item.data;
            this.tooltip.innerHTML = `
                <div class="tooltip-header station">
                    <span class="badge aqi-badge" style="background:${this.getAqiColor(st.aqi)}">${st.aqi} AQI</span>
                    <strong>${st.name}</strong>
                </div>
                <div class="tooltip-body">
                    <div>Type: <span>${st.type}</span></div>
                    <div>PM2.5: <strong>${st.pm25} µg/m³</strong> | PM10: <strong>${st.pm10}</strong></div>
                    <div>Parali Smoke Contribution: <strong style="color:#ff7043">${st.paraliPct}%</strong></div>
                    <div class="hint">Click to inspect monitoring station details</div>
                </div>
            `;
        } else if (item.type === 'fire') {
            const fire = item.data;
            this.tooltip.innerHTML = `
                <div class="tooltip-header fire">
                    <span class="badge fire-badge">🔥 Active Hotspot</span>
                    <strong>${fire.district}, ${fire.state}</strong>
                </div>
                <div class="tooltip-body">
                    <div>Active Thermal Fires: <strong style="color:#ff3d00">${fire.fireCount}</strong></div>
                    <div>Avg Fire Radiative Power: <strong>${fire.avgFRP} MW</strong></div>
                    <div>Status: <span>${fire.status}</span></div>
                    <div>Harvest Progress: <span>${fire.harvestProgress}</span></div>
                    <div class="hint">Click to inspect district biomass profile</div>
                </div>
            `;
        }
    }

    getAqiColor(aqi) {
        if (aqi <= 50) return '#00e676';
        if (aqi <= 100) return '#aeea00';
        if (aqi <= 200) return '#ffd600';
        if (aqi <= 300) return '#ff9100';
        if (aqi <= 400) return '#ff3d00';
        if (aqi <= 450) return '#d50000';
        return '#4a148c';
    }

    startAnimationLoop() {
        const render = () => {
            this.draw();
            requestAnimationFrame(render);
        };
        requestAnimationFrame(render);
    }

    draw() {
        this.ctx.clearRect(0, 0, this.width, this.height);

        // 1. Draw Map Canvas Background & Grid
        this.drawMapBase();

        // 2. Draw Regional Boundaries & Geographical Features
        if (this.layers.boundaries) {
            this.drawGeographicalRegions();
        }

        // 3. Draw Wind Vectors & Streamlines
        if (this.layers.windVectors) {
            this.drawWindField();
        }

        // 4. Draw Smoke Plume Particles
        if (this.layers.plumeParticles) {
            this.drawAndAnimateParticles();
        }

        // 5. Draw Active Fire Hotspots
        if (this.layers.fires) {
            this.drawFireHotspots();
        }

        // 6. Draw Urban Monitoring Stations
        if (this.layers.stations) {
            this.drawMonitoringStations();
        }

        // 7. Draw Map Scale & Compass
        this.drawCompassAndScale();
    }

    drawMapBase() {
        const ctx = this.ctx;
        // Dark geospatial canvas gradient
        const bgGrad = ctx.createRadialGradient(
            this.width / 2, this.height / 2, 80,
            this.width / 2, this.height / 2, Math.max(this.width, this.height)
        );
        bgGrad.addColorStop(0, '#0c1322');
        bgGrad.addColorStop(1, '#060a12');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, this.width, this.height);

        // Subtle coordinate grid lines
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.035)';
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 6]);

        for (let lat = 28.0; lat <= 32.5; lat += 1.0) {
            const p1 = this.geoToScreen(lat, this.geoBounds.minLng);
            const p2 = this.geoToScreen(lat, this.geoBounds.maxLng);
            ctx.beginPath();
            ctx.moveTo(0, p1.y);
            ctx.lineTo(this.width, p2.y);
            ctx.stroke();

            // Lat text
            ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.font = '10px monospace';
            ctx.fillText(`${lat.toFixed(1)}°N`, 8, p1.y - 4);
        }

        for (let lng = 74.0; lng <= 78.5; lng += 1.0) {
            const p1 = this.geoToScreen(this.geoBounds.minLat, lng);
            const p2 = this.geoToScreen(this.geoBounds.maxLat, lng);
            ctx.beginPath();
            ctx.moveTo(p1.x, 0);
            ctx.lineTo(p2.x, this.height);
            ctx.stroke();

            // Lng text
            ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.font = '10px monospace';
            ctx.fillText(`${lng.toFixed(1)}°E`, p1.x + 4, this.height - 8);
        }
        ctx.restore();
    }

    drawGeographicalRegions() {
        const ctx = this.ctx;
        ctx.save();

        // Approximate regional zones for Indo-Gangetic visual reference
        const regions = [
            {
                name: "PUNJAB (Primary Burning Basin)",
                color: "rgba(255, 87, 34, 0.06)",
                border: "rgba(255, 87, 34, 0.35)",
                points: [
                    { lat: 32.4, lng: 75.6 },
                    { lat: 31.8, lng: 76.2 },
                    { lat: 30.6, lng: 76.8 },
                    { lat: 29.9, lng: 75.8 },
                    { lat: 29.8, lng: 74.4 },
                    { lat: 30.8, lng: 74.1 },
                    { lat: 32.1, lng: 74.8 }
                ],
                labelLat: 31.2,
                labelLng: 75.2
            },
            {
                name: "HARYANA (Secondary Burning Belt)",
                color: "rgba(255, 171, 0, 0.05)",
                border: "rgba(255, 171, 0, 0.3)",
                points: [
                    { lat: 30.4, lng: 76.8 },
                    { lat: 29.9, lng: 77.2 },
                    { lat: 28.5, lng: 77.3 },
                    { lat: 28.0, lng: 76.2 },
                    { lat: 29.1, lng: 75.4 },
                    { lat: 29.9, lng: 75.8 }
                ],
                labelLat: 29.3,
                labelLng: 76.1
            },
            {
                name: "DELHI-NCR (Target Urban Airshed)",
                color: "rgba(255, 61, 0, 0.14)",
                border: "rgba(255, 61, 0, 0.7)",
                points: [
                    { lat: 28.85, lng: 77.05 },
                    { lat: 28.85, lng: 77.35 },
                    { lat: 28.45, lng: 77.40 },
                    { lat: 28.40, lng: 77.00 }
                ],
                labelLat: 28.64,
                labelLng: 77.21
            },
            {
                name: "WESTERN UTTAR PRADESH",
                color: "rgba(33, 150, 243, 0.03)",
                border: "rgba(33, 150, 243, 0.2)",
                points: [
                    { lat: 30.2, lng: 77.5 },
                    { lat: 29.2, lng: 78.4 },
                    { lat: 28.0, lng: 78.5 },
                    { lat: 28.2, lng: 77.5 }
                ],
                labelLat: 28.9,
                labelLng: 77.9
            }
        ];

        regions.forEach(reg => {
            ctx.beginPath();
            reg.points.forEach((pt, idx) => {
                const screenPt = this.geoToScreen(pt.lat, pt.lng);
                if (idx === 0) ctx.moveTo(screenPt.x, screenPt.y);
                else ctx.lineTo(screenPt.x, screenPt.y);
            });
            ctx.closePath();
            ctx.fillStyle = reg.color;
            ctx.fill();
            ctx.strokeStyle = reg.border;
            ctx.lineWidth = 1.4;
            ctx.stroke();

            // Label
            const lbl = this.geoToScreen(reg.labelLat, reg.labelLng);
            ctx.fillStyle = reg.border;
            ctx.font = '600 11px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(reg.name, lbl.x, lbl.y);
        });

        // Representative Yamuna River Line (Yamunanagar -> Panipat -> Delhi -> Mathura)
        const yamunaPts = [
            { lat: 30.15, lng: 77.32 },
            { lat: 29.40, lng: 77.10 },
            { lat: 28.80, lng: 77.20 },
            { lat: 28.65, lng: 77.26 },
            { lat: 28.40, lng: 77.35 },
            { lat: 27.90, lng: 77.60 }
        ];

        ctx.beginPath();
        yamunaPts.forEach((pt, idx) => {
            const p = this.geoToScreen(pt.lat, pt.lng);
            if (idx === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
        });
        ctx.strokeStyle = 'rgba(64, 196, 255, 0.4)';
        ctx.lineWidth = 2.0;
        ctx.stroke();

        const yLbl = this.geoToScreen(28.75, 77.22);
        ctx.fillStyle = 'rgba(64, 196, 255, 0.6)';
        ctx.font = 'italic 10px sans-serif';
        ctx.fillText("Yamuna Basin", yLbl.x + 40, yLbl.y);

        ctx.restore();
    }

    drawWindField() {
        const ctx = this.ctx;
        ctx.save();
        ctx.strokeStyle = 'rgba(100, 216, 255, 0.18)';
        ctx.fillStyle = 'rgba(100, 216, 255, 0.3)';
        ctx.lineWidth = 1.2;

        const arrowLen = Math.min(32, 12 + this.windSpeed * 0.9);
        const cos = Math.cos(this.windAngleRad);
        const sin = Math.sin(this.windAngleRad);

        // Grid of wind streamlines
        for (let lat = 28.4; lat <= 32.2; lat += 0.9) {
            for (let lng = 74.4; lng <= 78.0; lng += 0.9) {
                const pos = this.geoToScreen(lat, lng);
                const endX = pos.x + cos * arrowLen;
                const endY = pos.y + sin * arrowLen;

                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y);
                ctx.lineTo(endX, endY);
                ctx.stroke();

                // Arrow head
                const headLen = 4;
                ctx.beginPath();
                ctx.moveTo(endX, endY);
                ctx.lineTo(
                    endX - headLen * Math.cos(this.windAngleRad - Math.PI / 6),
                    endY - headLen * Math.sin(this.windAngleRad - Math.PI / 6)
                );
                ctx.lineTo(
                    endX - headLen * Math.cos(this.windAngleRad + Math.PI / 6),
                    endY - headLen * Math.sin(this.windAngleRad + Math.PI / 6)
                );
                ctx.fill();
            }
        }
        ctx.restore();
    }

    drawAndAnimateParticles() {
        const ctx = this.ctx;
        const cos = Math.cos(this.windAngleRad);
        const sin = Math.sin(this.windAngleRad);
        // Normal vector for perpendicular spread
        const normX = -sin;
        const normY = cos;

        const speedFactor = 0.6 + (this.windSpeed / 15) * 1.1;

        ctx.save();
        for (let i = 0; i < this.particles.length; i++) {
            const p = this.particles[i];
            p.age += 1;

            if (p.age >= p.maxLife) {
                this.particles[i] = this.spawnParticle(false);
                continue;
            }

            const origin = this.geoToScreen(p.originLat, p.originLng);
            const dist = p.age * speedFactor * 1.6;

            // Lateral Gaussian dispersion expands as particle travels downstream
            const lateralDispersion = p.spreadOffset * (1.0 + (p.age / p.maxLife) * 2.8);

            const currX = origin.x + cos * dist + normX * lateralDispersion;
            const currY = origin.y + sin * dist + normY * lateralDispersion;

            // Fade in then fade out
            const progress = p.age / p.maxLife;
            let alpha = p.alpha;
            if (progress < 0.15) alpha = p.alpha * (progress / 0.15);
            else if (progress > 0.65) alpha = p.alpha * (1.0 - (progress - 0.65) / 0.35);

            // Expanding radius
            const currentRadius = (p.radius + progress * 14) * this.scale;

            const smokeGrad = ctx.createRadialGradient(
                currX, currY, 0,
                currX, currY, currentRadius
            );
            smokeGrad.addColorStop(0, `rgba(255, 110, 64, ${alpha * 0.8})`);
            smokeGrad.addColorStop(0.4, `rgba(220, 80, 40, ${alpha * 0.45})`);
            smokeGrad.addColorStop(1, 'rgba(100, 40, 20, 0)');

            ctx.fillStyle = smokeGrad;
            ctx.beginPath();
            ctx.arc(currX, currY, currentRadius, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }

    drawFireHotspots() {
        const ctx = this.ctx;
        const time = Date.now() * 0.004;

        DEMO_DATA.fireHotspots.forEach(fire => {
            const pos = this.geoToScreen(fire.lat, fire.lng);
            const isHovered = this.hoveredItem && this.hoveredItem.data.id === fire.id;

            ctx.save();

            // Pulsing thermal glow
            const pulse = 1.0 + Math.sin(time + fire.fireCount) * 0.35;
            const radius = Math.min(18, 6 + (fire.fireCount / 40)) * pulse * this.scale;

            const glowGrad = ctx.createRadialGradient(pos.x, pos.y, 2, pos.x, pos.y, radius * 2.5);
            glowGrad.addColorStop(0, 'rgba(255, 61, 0, 0.9)');
            glowGrad.addColorStop(0.35, 'rgba(255, 110, 0, 0.5)');
            glowGrad.addColorStop(1, 'rgba(255, 61, 0, 0)');

            ctx.fillStyle = glowGrad;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, radius * 2.5, 0, Math.PI * 2);
            ctx.fill();

            // Core flame icon/dot
            ctx.fillStyle = '#fff7c2';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, Math.max(3, 4.5 * this.scale), 0, Math.PI * 2);
            ctx.fill();

            // Fire count label
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 10px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 4;
            ctx.fillText(`${fire.district} (${fire.fireCount})`, pos.x, pos.y + radius + 11);

            if (isHovered) {
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, radius * 1.3, 0, Math.PI * 2);
                ctx.stroke();
            }

            ctx.restore();
        });
    }

    drawMonitoringStations() {
        const ctx = this.ctx;
        DEMO_DATA.monitoringStations.forEach(st => {
            const pos = this.geoToScreen(st.lat, st.lng);
            const color = this.getAqiColor(st.aqi);
            const isHovered = this.hoveredItem && this.hoveredItem.data.id === st.id;

            ctx.save();

            // Pulse ring
            ctx.strokeStyle = color;
            ctx.lineWidth = isHovered ? 2.5 : 1.5;
            ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';

            ctx.beginPath();
            ctx.arc(pos.x, pos.y, (isHovered ? 13 : 10) * this.scale, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Center AQI indicator
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, 4 * this.scale, 0, Math.PI * 2);
            ctx.fill();

            // Station Tag
            ctx.fillStyle = '#e2e8f0';
            ctx.font = '600 10px system-ui, sans-serif';
            ctx.textAlign = 'left';
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 5;
            ctx.fillText(`${st.name.split(',')[0]} [${st.aqi}]`, pos.x + 12, pos.y + 3);

            ctx.restore();
        });
    }

    drawCompassAndScale() {
        const ctx = this.ctx;
        ctx.save();

        // 1. Compass Rose (Top Right)
        const compassX = this.width - 50;
        const compassY = 50;

        ctx.translate(compassX, compassY);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(0, 0, 24, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // North pointer
        ctx.fillStyle = '#ff3d00';
        ctx.beginPath();
        ctx.moveTo(0, -18);
        ctx.lineTo(5, -2);
        ctx.lineTo(-5, -2);
        ctx.closePath();
        ctx.fill();

        // South pointer
        ctx.fillStyle = '#94a3b8';
        ctx.beginPath();
        ctx.moveTo(0, 18);
        ctx.lineTo(5, 2);
        ctx.lineTo(-5, 2);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('N', 0, -20);

        ctx.restore();

        // 2. Map Scale Bar (Bottom Left)
        ctx.save();
        const p1 = this.geoToScreen(28.0, 75.0);
        const p2 = this.geoToScreen(28.0, 76.0);
        // Approx 1 deg longitude at 28 deg N is ~98 km
        const pixelPer100Km = (p2.x - p1.x) * (100 / 98);

        const scaleX = 24;
        const scaleY = this.height - 24;

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(scaleX, scaleY);
        ctx.lineTo(scaleX + pixelPer100Km, scaleY);
        ctx.moveTo(scaleX, scaleY - 4);
        ctx.lineTo(scaleX, scaleY + 4);
        ctx.moveTo(scaleX + pixelPer100Km, scaleY - 4);
        ctx.lineTo(scaleX + pixelPer100Km, scaleY + 4);
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('100 km (Indo-Gangetic Airshed)', scaleX + pixelPer100Km / 2, scaleY - 8);

        ctx.restore();
    }
}

// Make available globally
window.AgriSmokeMapEngine = AgriSmokeMapEngine;
